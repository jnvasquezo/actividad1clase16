public class principalHerencia {
    public static void main(String [] args){
        empleadoAsalariado ea1 = new empleadoAsalariado();
        ea1.setEmpresa("Apple");
        ea1.setNombre("Maria");
        ea1.setSalario(1000);

        System.out.println(ea1.getEmpresa());
        System.out.println(ea1.toString());
    }
}
