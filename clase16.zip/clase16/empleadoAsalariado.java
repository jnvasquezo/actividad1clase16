public class empleadoAsalariado extends empleado
{
    private int salario;
    public void setSalario(int s){
        this.salario=s;
    }

    public int getSalario(){
        return this.salario;
    }

    @Override
    public String toString(){
        String text = "empleadoAsalariado {nombre:" +this.getNombre();
        text = text + "empresa: "+this.getEmpresa()+"}";
        text = text + "empresa: "+this.getSalario()+"}";
        return text;
    }
}